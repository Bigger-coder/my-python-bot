import asyncio
import logging

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import MODE_INFO, MODE_LABELS, Mode, settings
from core.middlewares import OwnerOnlyMiddleware

router = Router()
USER_MODES: dict[int, Mode] = {}  # مؤقت


def main_menu(current: Mode | None) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    for mode, label in MODE_LABELS.items():
        mark = "✅ " if mode == current else ""
        kb.button(text=f"{mark}{label}", callback_data=f"mode:{mode.value}")
    kb.adjust(2)
    return kb.as_markup()


@router.message(CommandStart())
@router.message(Command("menu"))
async def show_menu(msg: Message):
    current = USER_MODES.get(msg.from_user.id)
    await msg.answer(
        "أهلاً بك 👋\nاختر وضع التشغيل:",
        reply_markup=main_menu(current),
    )


@router.callback_query(F.data.startswith("mode:"))
async def switch_mode(cb: CallbackQuery):
    mode = Mode(cb.data.split(":", 1)[1])
    if USER_MODES.get(cb.from_user.id) == mode:
        await cb.answer("هذا الوضع مفعّل بالفعل")
        return
    USER_MODES[cb.from_user.id] = mode
    try:
        await cb.message.edit_text(MODE_INFO[mode], reply_markup=main_menu(mode))
    except TelegramBadRequest:
        pass
    await cb.answer("تم تبديل الوضع ✅")


async def main():
    logging.basicConfig(level=logging.INFO)
    bot = Bot(
        settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()
    
    # تفعيل قفل الخصوصية (لك وحدك)
    dp.message.outer_middleware(OwnerOnlyMiddleware(settings.owner_id))
    dp.callback_query.outer_middleware(OwnerOnlyMiddleware(settings.owner_id))
    
    dp.include_router(router)
    
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
