from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message


class OwnerOnlyMiddleware(BaseMiddleware):
    def __init__(self, owner_id: int):
        self.owner_id = owner_id

    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if user and user.id == self.owner_id:
            return await handler(event, data)
        if isinstance(event, Message):
            await event.answer("⛔ هذا البوت خاص.")
        elif isinstance(event, CallbackQuery):
            await event.answer("⛔ غير مصرّح", show_alert=True)
        return None
